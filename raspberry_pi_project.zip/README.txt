
Raspberry Pi Camera and Speaker Project
----------------------------------------
This project uses OpenCV for real-time object detection and pyttsx3 for text-to-speech functionality.
Steps to Run:
1. Ensure all dependencies are installed: OpenCV, pyttsx3.
2. Connect a camera and speaker to the Raspberry Pi.
3. Run the main.py script: `python3 main.py`.
4. Press 'q' to quit the program.

Enjoy the demo!
