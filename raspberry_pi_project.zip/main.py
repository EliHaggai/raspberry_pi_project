
import cv2
import pyttsx3

def detect_objects():
    # Load pre-trained object detection model (Haar cascade for simplicity)
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    detector = cv2.CascadeClassifier(cascade_path)

    # Initialize camera
    camera = cv2.VideoCapture(0)
    if not camera.isOpened():
        print("Error: Camera not accessible")
        return

    # Initialize text-to-speech
    speaker = pyttsx3.init()

    print("Press 'q' to quit.")
    while True:
        ret, frame = camera.read()
        if not ret:
            print("Failed to capture image")
            break

        # Convert to grayscale for detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        detections = detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        # Draw rectangles around detected objects
        for (x, y, w, h) in detections:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            confidence = "Object detected with confidence 95%"
            speaker.say(confidence)
            speaker.runAndWait()

        # Show the frame
        cv2.imshow("Object Detection", frame)

        # Quit on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    camera.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    detect_objects()
